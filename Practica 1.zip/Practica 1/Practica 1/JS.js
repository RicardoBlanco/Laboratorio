openNewWindowA = function(){
 window.open("https://www.google.com.mx/search?source=hp&ei=L1aPW_PROYn4wALXsY2YCA&q=Aceptar&oq=Aceptar&gs_l=psy-ab.3..0l10.25344.27325.0.28358.10.6.0.0.0.0.433.685.2-1j0j1.2.0....0...1.1.64.psy-ab..8.2.683.0..0i67k1j0i131k1.0.d5uSRyp8-Mo");
};

openNewWindowC = function(){
 window.open("https://www.google.com.mx/search?hl=es-419&ei=b1aPW_ybHauRlwSk_pnoCg&q=cancelacion&oq=cancelacion&gs_l=psy-ab.3...1062.2254.0.2482.5.5.0.0.0.0.281.281.2-1.1.0....0...1.1.64.psy-ab..4.1.280...0j35i39k1j0i67k1j0i131k1.0.3zIZDOAhIhc");
};

openNewWindowI = function(){
 window.open("https://www.google.com.mx/search?hl=es-419&ei=s1aPW7mqG5K00gWdh6KoAw&q=informacion+definicion&oq=informacion&gs_l=psy-ab.3.7.35i39k1l2j0i131k1l3j0j0i131k1l4.3075.4752.0.9405.8.8.0.0.0.0.332.775.2-2j1.3.0....0...1.1.64.psy-ab..5.3.773...0i131i67k1j0i67k1.0.7_s5huLTzdA");
};